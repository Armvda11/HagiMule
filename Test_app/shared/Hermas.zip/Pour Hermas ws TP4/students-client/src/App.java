import javax.ws.rs.core.UriBuilder;

import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

public class App {
    public static void main(String[] args) {
    final String path = "http://localhost:8080/";
    ResteasyClient client = new ResteasyClientBuilder().build();
    ResteasyWebTarget target = client.target(UriBuilder.fromPath(path));
    StudentControllerInterface proxy = target.proxy(StudentControllerInterface.class);
    Student resp;
    resp = proxy.getStudent("Boris", "Teabe");
    System.out.println(resp.getFirstname() + " " + resp.getLastname());
}
}
