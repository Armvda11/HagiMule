package n7.students_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentsServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
