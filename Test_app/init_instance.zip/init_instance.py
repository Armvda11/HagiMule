import boto3
import os
import time
import paramiko
import json

# Configuration par région
region_configs = {
        'eu-central-1': {
            'image_id': 'ami-0a628e1e89aaedf80',
            'security_group_ids': ['sg-0f51617ec59395e2f'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'eu-west-3': {
            'image_id': 'ami-09be70e689bddcef5',
            'security_group_ids': ['sg-0e14ce3b3e9eec70c'],
            'instance_type': 't2.micro',
            'limit_vcpu': 32
        },
        'eu-west-1': {
            'image_id': 'ami-0e9085e60087ce171',
            'security_group_ids': ['sg-03d6d056a4bf77463'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'eu-west-2': {
            'image_id': 'ami-05c172c7f0d3aed00',
            'security_group_ids': ['sg-06077559d78c7bafd'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'eu-north-1': {
            'image_id': 'ami-075449515af5df0d1',
            'security_group_ids': ['sg-0579fef4ed738af6a'],
            'instance_type': 't3.micro',
            'limit_vcpu': 32
        },
        'sa-east-1': {
            'image_id': 'ami-015f3596bb2ef1aaa',
            'security_group_ids': ['sg-051200abd21983bc4'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'ca-central-1': {
            'image_id': 'ami-0bee12a638c7a8942',
            'security_group_ids': ['sg-0b866987ae57cba14'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'us-east-1': {
            'image_id': 'ami-0e2c8caa4b6378d8c',
            'security_group_ids': ['sg-076503217fd0cadd2'],
            'instance_type': 't2.micro',
            'limit_vcpu': 32
        },
        'us-east-2': {
            'image_id': 'ami-036841078a4b68e14',
            'security_group_ids': ['sg-05e03db573702a65a'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'us-west-2': {
            'image_id': 'ami-0af9ac10a534a823b',
            'security_group_ids': ['sg-0f66e84f1dcc02af0'],
            'instance_type': 't2.micro',
            'limit_vcpu': 32
        },
        'us-west-1': {
            'image_id': 'ami-0657605d763ac72a8',
            'security_group_ids': ['sg-05cceefc514de6b1d'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'ap-south-1': {
            'image_id': 'ami-053b12d3152c0cc71',
            'security_group_ids': ['sg-018daf3d010dc384c'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'ap-northeast-3': {
            'image_id': 'ami-0b9294510d1a4fafa',
            'security_group_ids': ['sg-0355a23ba1ecce2d0'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'ap-northeast-2': {
            'image_id': 'ami-0dc44556af6f78a7b',
            'security_group_ids': ['sg-0047f82bc052715d2'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'ap-northeast-1': {
            'image_id': 'ami-0b2cd2a95639e0e5b',
            'security_group_ids': ['sg-08c33ddc2b5d9dac1'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'ap-southeast-1': {
            'image_id': 'ami-06650ca7ed78ff6fa',
            'security_group_ids': ['sg-0fabe6dc54a0a2064'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        },
        'ap-southeast-2': {
            'image_id': 'ami-003f5a76758516d1e',
            'security_group_ids': ['sg-048728031ef32245a'],
            'instance_type': 't2.micro',
            'limit_vcpu': 5
        }
    }

def create_key_pair(ec2_client, key_name):
    try:
        # Check if key pair exists
        try:
            ec2_client.describe_key_pairs(KeyNames=[key_name])
            print(f"Key pair '{key_name}' already exists.")
            return key_name
        except ec2_client.exceptions.ClientError:
            # Create new key pair if it doesn't exist
            key_pair = ec2_client.create_key_pair(KeyName=key_name)
            with open(f"{key_name}.pem", "w") as file:
                file.write(key_pair['KeyMaterial'])
            os.chmod(f"{key_name}.pem", 0o400)
            print(f"Key pair '{key_name}' created and saved as '{key_name}.pem'")
            return key_name
    except Exception as e:
        print(f"Error creating key pair: {str(e)}")
        raise
        
def import_or_create_key_pair(ec2_client, key_name, public_key=None):
    try:
        # Vérifie si la clé existe déjà
        ec2_client.describe_key_pairs(KeyNames=[key_name])
        print(f"Key pair '{key_name}' already exists in this region.")
        return key_name
    except ec2_client.exceptions.ClientError:
        if public_key:
            # Importe la clé publique existante
            ec2_client.import_key_pair(
                KeyName=key_name,
                PublicKeyMaterial=public_key
            )
            print(f"Key pair '{key_name}' imported in this region.")
        else:
            # Crée une nouvelle paire de clés seulement dans la première région
            key_pair = ec2_client.create_key_pair(KeyName=key_name)
            with open(f"{key_name}.pem", "w") as file:
                file.write(key_pair['KeyMaterial'])
            os.chmod(f"{key_name}.pem", 0o400)
            print(f"Key pair '{key_name}' created and saved as '{key_name}.pem'")
            
            # Lit la clé publique à partir de la clé privée
            key = paramiko.RSAKey.from_private_key_file(f"{key_name}.pem")
            public_key = f"ssh-rsa {key.get_base64()}"
            print(f"New key pair '{key_name}' created.")
            return public_key
        

def create_instances(ec2_resource, image_id, instance_type, key_name, security_group_ids, instance_count):
    try:
        # Obtenir la région depuis le client
        region_name = ec2_resource.meta.client.meta.region_name
        instances = ec2_resource.create_instances(
            ImageId=image_id,
            InstanceType=instance_type,
            KeyName=key_name,
            SecurityGroupIds=security_group_ids,
            MinCount=instance_count,
            MaxCount=instance_count
        )

        print(f"Created {instance_count} instances in region {region_name}")
        # Attacher les noms aux instances via les tags
        for index, instance in enumerate(instances, start=1):
            instance_name = f"machine-{region_name}-{index}"
            instance.create_tags(
                Tags=[
                    {"Key": "Name", "Value": instance_name}
                ]
            )
            print(f"Instance {instance.id} named as {instance_name}")

        for instance in instances:
            instance.wait_until_running()
            instance.reload()
            print(f"Instance ID: {instance.id}, Public IP: {instance.public_ip_address}, State: {instance.state['Name']}")

        return instances
    except Exception as e:
        print(f"Error creating instances: {str(e)}")
        raise
def create_instances(ec2_resource, image_id, instance_type, key_name, security_group_ids, instance_count):
    try:
        # Obtenir la région depuis le client
        region_name = ec2_resource.meta.client.meta.region_name
        instances = ec2_resource.create_instances(
            ImageId=image_id,
            InstanceType=instance_type,
            KeyName=key_name,
            SecurityGroupIds=security_group_ids,
            MinCount=instance_count,
            MaxCount=instance_count
        )

        print(f"Created {instance_count} instances in region {region_name}")
           # Attacher les noms aux instances via les tags
        for index, instance in enumerate(instances, start=1):
            instance_name = f"machine-{region_name}-{index}"
            instance.create_tags(
                Tags=[
                    {"Key": "Name", "Value": instance_name}
                ]
            )
            print(f"Instance {instance.id} named as {instance_name}")
        
  
        for instance in instances:
            instance.wait_until_running()
            instance.reload()
            print(f"Instance ID: {instance.id}, Public IP: {instance.public_ip_address}, State: {instance.state['Name']}")
        
        return instances
    except Exception as e:
        print(f"Error creating instances: {str(e)}")
        raise

def configure_security_groups(ec2_client, security_group_ids):
    """
    Configure les security groups pour permettre RMI et les communications socket
    """
    for sg_id in security_group_ids:
        try:
            # Autoriser le trafic RMI entrant
            ec2_client.authorize_security_group_ingress(
                GroupId=sg_id,
                IpPermissions=[
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 22,
                        'ToPort': 22,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
                    },
                       {
                        'IpProtocol': 'tcp',
                        'FromPort': 80,
                        'ToPort': 80,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
                    },
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 443,
                        'ToPort': 443,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
                    },
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 1099,
                        'ToPort': 1099,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
                    },
                    {
                        'IpProtocol': 'tcp',
                        'FromPort': 1024,
                        'ToPort': 65535,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
                    },
                    
                     {
                        'IpProtocol': '-1',  # Tous les protocoles
                        'FromPort': -1,
                        'ToPort': -1,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
                    }
                                        
                    
                ]
            )
            
            # Autoriser le trafic sortant (déjà permis par défaut mais on le précise)
            ec2_client.authorize_security_group_egress(
                GroupId=sg_id,
                IpPermissions=[
                    {
                        'IpProtocol': '-1',  # Tous les protocoles
                        'FromPort': -1,
                        'ToPort': -1,
                        'IpRanges': [{'CidrIp': '0.0.0.0/0'}]
                    }
                ]
            )
            
            print(f"Security group {sg_id} configured successfully")
            
        except ec2_client.exceptions.ClientError as e:
            if e.response['Error']['Code'] == 'InvalidPermission.Duplicate':
                print(f"Rules already exist for security group {sg_id}")
            else:
                print(f"Error configuring security group {sg_id}: {e}")

def main(region_instance_counts, aws_access_key, aws_secret_key, key_name):
    all_instances = []

    # Crée la clé dans la première région
    first_region = "eu-west-3"
    first_session = boto3.Session(
        aws_access_key_id=aws_access_key,
        aws_secret_access_key=aws_secret_key,
        region_name=first_region
    )
    first_ec2_client = first_session.client('ec2')
    public_key = import_or_create_key_pair(first_ec2_client, key_name)

    for region, instance_count in region_instance_counts.items():
        if instance_count > 0:
            try:
                # Create AWS clients with explicit credentials
                session = boto3.Session(
                    aws_access_key_id=aws_access_key,
                    aws_secret_access_key=aws_secret_key,
                    region_name=region
                )
                ec2_client = session.client('ec2')
                ec2_resource = session.resource('ec2')

                # Configurer les security groups
                security_group_ids = region_configs[region]['security_group_ids']
                configure_security_groups(ec2_client, security_group_ids)

                # Get region-specific configuration
                config = region_configs[region]
                image_id = config['image_id']
                instance_type = config['instance_type']
                security_group_ids = config['security_group_ids']

                # Create instances
                if region != first_region:
                    import_or_create_key_pair(ec2_client, key_name, public_key)
                instances = create_instances(ec2_resource, image_id, instance_type, key_name, 
                                          security_group_ids, instance_count)
                
                         # Ajouter la région à chaque instance
                for instance in instances:
                    instance_info = {
                        'id': instance.id,
                        'public_dns_name': instance.public_dns_name,
                        'region': region  # Ajouter la région ici
                    }
                    all_instances.append(instance_info)

                #all_instances.extend(instances)

            except Exception as e:
                print(f"Error in region {region}: {str(e)}")
                continue

    return all_instances

if __name__ == "__main__":
    regions = [
        'eu-west-3', 'eu-west-1', 'eu-west-2', 'eu-north-1', 'sa-east-1', 
        'ap-south-1', 'ap-northeast-3', 'ap-northeast-2', 'ap-northeast-1', 
        'ap-southeast-1', 'ap-southeast-2', 'ca-central-1', 'eu-central-1', 
        'us-east-2', 'us-east-1', 'us-west-2', 'us-west-1'
    ]

    # AWS credentials configuration
    # aws_access_key = input("Enter your AWS Access Key ID: ")
    # aws_secret_key = input("Enter your AWS Secret Access Key: ")

    aws_access_key="AKIAYDWHTDEGZUQHKVXP"
    aws_secret_key="1CmC7Mzof5C7nAI2e9hKjyU/q6Ovxqrf7vOZQ4oj"
    key_name = 'my-ec2-key-paire'

 
    config_choice = input("Do you want to use the default configuration (d) or the manual configuration (m)? ").strip().lower()

    if config_choice == 'd':
        region_instance_counts = {region: 1 for region in regions}
        region_instance_counts['eu-west-3'] = 10
        region_instance_counts['eu-west-2'] = 4
        region_instance_counts['ap-southeast-1'] = 3
    elif config_choice == 'm':
        region_instance_counts = {}
        for region in regions:
            count = int(input(f"Enter the number of instances to create in {region} (max {region_configs[region]['limit_vcpu']}): "))
            region_instance_counts[region] = count
    else:
        print("Invalid choice. Using default configuration")
        region_instance_counts = {region: 1 for region in regions}
        region_instance_counts['eu-west-3'] = 10
        region_instance_counts['eu-west-2'] = 4
        region_instance_counts['ap-southeast-1'] = 3

    for region, count in region_instance_counts.items():
        print(f"{region}: {count} instances (max vCPU: {region_configs[region]['limit_vcpu']})")

    all_instances = main(region_instance_counts, aws_access_key, aws_secret_key, key_name)

    # Sauvegarder all_instances dans un fichier pour utilisation ultérieure
    # all_instances_info = [{'id': instance.id, 'public_dns_name': instance.public_dns_name} for instance in all_instances]
    # with open('instances.json', 'w') as f:
    #     json.dump(all_instances_info, f)
        # Sauvegarder all_instances dans un fichier pour utilisation ultérieure
    with open('instances.json', 'w') as f:
        json.dump(all_instances, f, indent=4)